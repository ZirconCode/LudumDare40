
Ingredients of Insanity
======

This game was created with love by Simon (zirconcode) and Spargles for the LudumDare 40 (Jam).

Instructions in game, press `esc` anytime to close the game =)

Enjoy!


How to Run:
======

=> Unpack the .zip

Windows: 
=> Run the IngredientsOfInsanity.exe! (32/64 bit version)

Linux / Mac: 
=> Download and install Love2D from https://love2d.org/
=> Run `love IngredientsOfInsanity.love` 

Alternatively, download the Source and play around with it =)


Source:
======

https://github.com/ZirconCode/LudumDare40


Created Using:
======

Created with lua/Love2D, an amazing library/engine!

We used Tiled (www.mapeditor.org) as a map editor, thank you Thorbjørn Lindeijer and others for this wonderful and simple editor.

Love2D License:
https://love2d.org/wiki/License


